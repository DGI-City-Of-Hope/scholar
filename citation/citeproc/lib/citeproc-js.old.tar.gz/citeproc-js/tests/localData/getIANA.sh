wget http://www.iana.org/assignments/language-subtag-registry
